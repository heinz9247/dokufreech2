<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author lainme <lainme993@gmail.com>
 */
$lang['__background_site__']   = '特别背景的颜色 (内容框后面)';
$lang['__link__']              = '一般链接的颜色';
$lang['__existing__']          = '指向存在的页面的链接颜色';
$lang['__missing__']           = '指向不存在的页面的链接颜色';
$lang['__site_width__']        = '全站的宽度 (可以是任何长度单位：%，px，em，...)';
$lang['__sidebar_width__']     = '侧边栏的宽度 (如有，可以是任何长度单位：%，px，em，...)';
$lang['__tablet_width__']      = '当屏幕尺寸小于这个宽度，站点切换到平板模式';
$lang['__phone_width__']       = '当屏幕尺寸小于这个宽度，站点切换到手机模式';
