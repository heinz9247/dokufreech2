<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Arne Hanssen <arne.hanssen@getmail.no>
 */
$lang['__background_site__']   = 'Farge for bakerste bakgrunn (bak innholdsboksen)';
$lang['__link__']              = 'Generell lenkefarge';
$lang['__existing__']          = 'Farge for lenker til eksisterende sider';
$lang['__missing__']           = 'Farge for lenker til ikke-eksisterende sider';
$lang['__site_width__']        = 'Bredde for hele siden (kan angis i ulike enheter som: (%, px, em, ...)';
$lang['__sidebar_width__']     = 'Sidestolpens bredde, dersom denne finnes (kan angis i ulike enheter som: (%, px, em, ...)';
$lang['__tablet_width__']      = 'For skjermbredde lavere en denne verden, vil siden endres til å vises i brett-modus';
$lang['__phone_width__']       = 'For skjermbredde lavere en denne verden, vil siden endres til å vises i mobil-modus';
