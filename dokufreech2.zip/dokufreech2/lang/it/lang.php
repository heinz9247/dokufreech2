<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Torpedo <dgtorpedo@gmail.com>
 */
$lang['__background_site__']   = 'Colore per lo sfondo di livello più basso (dietro il riquadro del contenuto)';
$lang['__link__']              = 'Colore generale per i link';
$lang['__existing__']          = 'Colore per i collegamenti alle pagine esistenti';
$lang['__missing__']           = 'Colore per i collegamenti alle pagine non esistenti';
$lang['__site_width__']        = 'Larghezza dell\'intero sito (può essere una qualunque unità di lunghezza: %, px, em, ...)';
$lang['__sidebar_width__']     = 'Larghezza della barra laterale, se presente (può essere una qualunque unità di lunghezza: %, px, em, ...)';
$lang['__tablet_width__']      = 'Per dimensioni dello schermo al di sotto di questa larghezza, il sito passa in modalità tablet';
$lang['__phone_width__']       = 'Per dimensioni dello schermo al di sotto di questa larghezza, il sito passa in modalità telefono';
